# RiFarm — Guide d'intégration production
## Du prototype vers une vraie Telegram Mini App

---

## STACK RECOMMANDÉE

| Couche | Technologie | Pourquoi |
|---|---|---|
| Frontend | HTML/CSS/JS (fichier actuel) | Déjà prêt, Telegram-compatible |
| Backend API | Supabase (PostgreSQL + Auth) | Gratuit, temps réel, Auth Telegram |
| Upload média | Cloudinary | Compression auto, CDN mondial |
| Déploiement | Vercel ou Netlify | Gratuit, HTTPS auto |
| Bot Telegram | Node.js + grammy | Déclenche la Mini App |

---

## ÉTAPE 1 — SUPABASE (Base de données)

### 1.1 Créer le projet
1. Aller sur https://supabase.com → New Project
2. Nommer : `rifarm-production`
3. Choisir région : `EU West` (Frankfurt)
4. Noter : `SUPABASE_URL` et `SUPABASE_ANON_KEY`

### 1.2 Schéma SQL — coller dans l'éditeur Supabase

```sql
-- Table produits
CREATE TABLE products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('Dry Sift','Frozen Sift','Static','Beldia','Premium Edition')),
  grade TEXT NOT NULL DEFAULT 'GOLD',
  price INTEGER NOT NULL,
  stock TEXT NOT NULL DEFAULT 'in' CHECK (stock IN ('in','low','out')),
  texture TEXT,
  color TEXT,
  origin TEXT,
  terps TEXT[], -- tableau de terpènes
  purity INTEGER DEFAULT 80 CHECK (purity BETWEEN 0 AND 100),
  arome INTEGER DEFAULT 80 CHECK (arome BETWEEN 0 AND 100),
  featured BOOLEAN DEFAULT FALSE,
  image_url TEXT,
  video_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table uploads médias
CREATE TABLE media (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID REFERENCES products(id) ON DELETE CASCADE,
  type TEXT CHECK (type IN ('image','video')),
  url TEXT NOT NULL,
  cloudinary_public_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS (Row Level Security) — lecture publique, écriture admin
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE media ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public read" ON products FOR SELECT USING (TRUE);
CREATE POLICY "Public read media" ON media FOR SELECT USING (TRUE);

-- Pour l'admin : créer une policy avec JWT Telegram ou service_role key
```

### 1.3 Connecter au frontend

Ajouter dans le `<head>` de `rifarm_catalogue.html` :

```html
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
```

Remplacer le tableau `products` statique par :

```javascript
const { createClient } = supabase;
const db = createClient('VOTRE_SUPABASE_URL', 'VOTRE_ANON_KEY');

// Charger les produits
async function loadProducts() {
  const { data, error } = await db
    .from('products')
    .select('*')
    .order('featured', { ascending: false });
  
  if (!error) {
    products = data;
    renderGrid();
    renderFilters();
  }
}

// Ajouter un produit
async function addProduct(productData) {
  const { data, error } = await db
    .from('products')
    .insert([productData])
    .select();
  
  if (!error) {
    products.push(data[0]);
    renderGrid();
    toast('✦ Produit ajouté');
  }
}

// Modifier
async function updateProduct(id, updates) {
  const { error } = await db
    .from('products')
    .update({ ...updates, updated_at: new Date() })
    .eq('id', id);
  
  if (!error) {
    // mettre à jour localement
    const idx = products.findIndex(p => p.id === id);
    if (idx !== -1) products[idx] = { ...products[idx], ...updates };
    renderGrid();
    toast('✓ Produit modifié');
  }
}

// Supprimer
async function deleteProduct(id) {
  const { error } = await db
    .from('products')
    .delete()
    .eq('id', id);
  
  if (!error) {
    products = products.filter(p => p.id !== id);
    renderGrid();
    toast('Produit supprimé');
  }
}

// Temps réel — mise à jour instantanée
db.channel('products')
  .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, payload => {
    loadProducts(); // refresh automatique
  })
  .subscribe();

// Lancer au démarrage
loadProducts();
```

---

## ÉTAPE 2 — CLOUDINARY (Upload médias)

### 2.1 Setup
1. Créer un compte sur https://cloudinary.com (gratuit 25GB)
2. Dashboard → Settings → Upload → Add upload preset
3. Nommer : `rifarm_uploads`, mode : `Unsigned`
4. Activer : compression automatique, formats modernes (WebP/AVIF)
5. Noter : `CLOUD_NAME` et `UPLOAD_PRESET`

### 2.2 Remplacer l'upload fictif dans le frontend

```javascript
async function uploadMedia(file, productId) {
  const CLOUD_NAME = 'votre_cloud_name';
  const UPLOAD_PRESET = 'rifarm_uploads';
  
  // Afficher la progression
  showProgress(0);
  
  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', UPLOAD_PRESET);
  formData.append('folder', 'rifarm/products');
  
  // Transformation auto : compression + resize
  if (file.type.startsWith('image/')) {
    formData.append('transformation', 'f_auto,q_auto,w_800');
  } else {
    // Vidéo : compression H.264
    formData.append('transformation', 'f_mp4,q_auto:low,w_1080');
  }
  
  const type = file.type.startsWith('video/') ? 'video' : 'image';
  const endpoint = `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/${type}/upload`;
  
  const xhr = new XMLHttpRequest();
  
  xhr.upload.addEventListener('progress', e => {
    const pct = Math.round((e.loaded / e.total) * 100);
    showProgress(pct);
  });
  
  xhr.onload = async () => {
    const result = JSON.parse(xhr.responseText);
    showProgress(100);
    
    // Sauvegarder dans Supabase
    await db.from('media').insert([{
      product_id: productId,
      type,
      url: result.secure_url,
      cloudinary_public_id: result.public_id
    }]);
    
    // Mettre à jour le produit
    const field = type === 'image' ? 'image_url' : 'video_url';
    await updateProduct(productId, { [field]: result.secure_url });
    
    toast('✓ Média uploadé');
  };
  
  xhr.open('POST', endpoint);
  xhr.send(formData);
}

// Déclencher depuis le bouton upload
document.getElementById('upload-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  
  // Preview immédiat avant upload
  const preview = URL.createObjectURL(file);
  document.getElementById('preview-area').src = preview;
  
  await uploadMedia(file, currentProductId);
});
```

### 2.3 Ajouter le bouton file dans le HTML admin

```html
<input type="file" id="upload-input" accept="image/*,video/*" style="display:none" 
       onchange="handleFileSelect(event)">
<div class="admin-img-area" onclick="document.getElementById('upload-input').click()">
  ...
</div>
```

---

## ÉTAPE 3 — BOT TELEGRAM + MINI APP

### 3.1 Créer le bot
1. Ouvrir Telegram → chercher @BotFather
2. `/newbot` → nommer : `RiFarmBot`
3. `/newapp` → sélectionner le bot
4. Web App URL : `https://votre-rifarm.vercel.app`
5. Copier le `BOT_TOKEN`

### 3.2 Intégrer le SDK Telegram dans le frontend

Ajouter dans `<head>` :

```html
<script src="https://telegram.org/js/telegram-web-app.js"></script>
```

Ajouter au début du `<script>` :

```javascript
// Initialiser Telegram WebApp
const tg = window.Telegram?.WebApp;

if (tg) {
  tg.ready();
  tg.expand(); // plein écran
  tg.setHeaderColor('#06060a');
  tg.setBackgroundColor('#06060a');
  
  // Récupérer l'utilisateur Telegram
  const user = tg.initDataUnsafe?.user;
  if (user) {
    console.log('User:', user.id, user.first_name);
    // Vérifier si admin (comparer user.id à la liste admins)
    isAdmin = ADMIN_IDS.includes(user.id);
  }
  
  // Bouton principal Telegram
  tg.MainButton.setText('Commander').show();
  tg.MainButton.onClick(() => {
    if (detailId) {
      tg.sendData(JSON.stringify({ action: 'order', productId: detailId }));
    }
  });
  
  // Bouton retour Telegram natif
  tg.BackButton.onClick(() => {
    if (document.querySelector('.det-ov.open')) closeDetail();
    else if (document.querySelector('.admin-ov.open')) closeAdmin();
  });
}

// Admin IDs autorisés (Telegram user IDs)
const ADMIN_IDS = [123456789]; // remplacer par vos IDs
let isAdmin = false;
```

### 3.3 Authentification Telegram (validation côté serveur)

```javascript
// Vérifier que les données viennent bien de Telegram
// À faire côté backend Node.js

const crypto = require('crypto');

function validateTelegramData(initData, botToken) {
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  params.delete('hash');
  
  const dataCheckString = Array.from(params.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join('\n');
  
  const secretKey = crypto
    .createHmac('sha256', 'WebAppData')
    .update(botToken)
    .digest();
  
  const expectedHash = crypto
    .createHmac('sha256', secretKey)
    .update(dataCheckString)
    .digest('hex');
  
  return hash === expectedHash;
}
```

---

## ÉTAPE 4 — DÉPLOIEMENT VERCEL

### 4.1 Structure du projet

```
rifarm/
├── index.html          ← le fichier catalogue actuel
├── vercel.json         ← config déploiement
└── .env                ← variables d'environnement
```

### 4.2 vercel.json

```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "X-Frame-Options", "value": "ALLOWALL" },
        { "key": "Content-Security-Policy", "value": "frame-ancestors *" }
      ]
    }
  ]
}
```

### 4.3 Déployer

```bash
# Installer Vercel CLI
npm install -g vercel

# Dans le dossier rifarm/
vercel

# Suivre les instructions → URL générée automatiquement
# ex: https://rifarm-xxx.vercel.app
```

---

## ÉTAPE 5 — VARIABLES D'ENVIRONNEMENT

Créer un fichier `.env` (ne jamais committer sur Git) :

```env
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_ANON_KEY=eyJhbGc...
CLOUDINARY_CLOUD_NAME=rifarm
CLOUDINARY_UPLOAD_PRESET=rifarm_uploads
TELEGRAM_BOT_TOKEN=1234567890:ABC...
ADMIN_TELEGRAM_IDS=123456789,987654321
```

Dans Vercel Dashboard → Settings → Environment Variables → ajouter chaque variable.

Dans le frontend (injecter au build ou charger via API) :

```javascript
// Option simple : endpoint /config sur votre backend
const config = await fetch('/api/config').then(r => r.json());
const db = createClient(config.supabaseUrl, config.supabaseKey);
```

---

## RÉSUMÉ — ORDRE D'EXÉCUTION

```
1. Créer projet Supabase → copier URL + Key
2. Créer le schéma SQL (copier-coller le SQL ci-dessus)
3. Créer compte Cloudinary → noter Cloud Name + Preset
4. Créer le bot Telegram via @BotFather → noter BOT_TOKEN
5. Modifier index.html → remplacer les 4 blocs de code indiqués
6. Déployer sur Vercel → obtenir l'URL HTTPS
7. Configurer la Mini App dans BotFather avec l'URL Vercel
8. Tester sur Telegram iOS + Android
```

---

## COÛTS

| Service | Plan gratuit | Limite |
|---|---|---|
| Supabase | Free | 500MB DB, 2GB storage |
| Cloudinary | Free | 25GB, 25K transformations/mois |
| Vercel | Free | Déploiements illimités |
| Telegram Bot | Gratuit | Illimité |

**Total : 0€/mois** pour un catalogue jusqu'à ~500 produits et ~1000 utilisateurs/mois.
